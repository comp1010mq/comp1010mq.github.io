

public class Cube {
	private double side;

	public double getSide() {
		return side;
	}

	public void setSide(double side) {
		this.side = Math.max(0, side);
	}
	
	public Cube() {
		setSide(0);
	}
	
	public Cube(double side) {
		setSide(side);
	}
	
	public double volume() {
		return side*side*side;
	}
	
	public String toString() {
		return "cube of size "+side;
	}
}
