

/**
 * email address is stored as a combination of username and domain
 * for example, username = "gaurav.gupta"
 * domain = "mq.edu.au"
 * thus the email address is "gaurav.gupta@mq.edu.au"
 * @author gauravgupta
 *
 */
public class EmailAddress {
	private String username, domain;

	public String getUsername() {
		return username;
	}

	public String getDomain() {
		return domain;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public EmailAddress(String username, String domain) {
		setUsername(username);
		setDomain(domain);
	}
	
	public EmailAddress() {
		setUsername("tba");
		setDomain("gmail.com");
	}

	public String toString() {
		return username+"@"+domain;
	}
	
	/**
	 * 
	 * @param other
	 * @return
	 * true if the calling object and the parameter object refer to the exact same email address
	 * false otherwise
	 */
	public boolean equals(EmailAddress other) {
		return username.equals(other.username) && domain.equals(other.domain);
	}
}
