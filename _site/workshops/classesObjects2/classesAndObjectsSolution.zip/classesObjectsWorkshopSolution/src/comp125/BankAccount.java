/**
 * A BankAccount class that manages the balance of an account
 */
package comp125;

/**
 * @author <type your name here>
 *
 */
public class BankAccount {

	// TODO You need to add the data variable (also known as instance variable)
	// that will store the account balance.
	private double balance;
	
	/**
	 * Constructor that initializes the balance to zero.
	 * Actually Java provides this constructor by default,
	 * but it is better to include it explicitly in your class.
	 * Please note that we are setting the balance to zero through
	 * the setter {@link this#setBalance(double)} since this creates
	 * a single point of modification for data member {@link this#balance}
	 * and is thus recommended
	 */
	public BankAccount() {
		setBalance(0);
	}
	
	/**
	 * Return the balance of the account.
	 * @return the balance
	 */
	public double getBalance() {
		// TODO Auto-generated method stub
		return balance;  // You might want to change this statement.
	}
	
	/**
	 * since balance can be negative or postive (or zero), there is really 
	 * no validation rule here
	 * @param bal
	 */
	public void setBalance(double bal) {
		balance = bal;
	}

	/**
	 * Increase the balance by the amount specified.
	 * @param amount
	 */
	public void deposit(double amount) {
		// TODO Auto-generated method stub
		setBalance(balance+amount);
	}

	/**
	 * Decrease the balance by the amount specified. It's OK if the resulting
	 * balance is negative (overdrawn).
	 * @param amount
	 */
	public void withdraw(double amount) {
		// TODO Auto-generated method stub
		setBalance(balance-amount);
	}

	/**
	 * Check if the balance is overdrawn.
	 * @return true if the balance is negative.
	 */
	public boolean overdrawn() {
		// TODO Auto-generated method stub
		return balance < 0;  // You might want to change this statement.
	}

}
