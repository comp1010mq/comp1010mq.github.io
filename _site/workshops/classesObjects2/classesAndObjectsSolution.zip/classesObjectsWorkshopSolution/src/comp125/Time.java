package comp125;

public class Time {
	private int hour, minute, second;

	//setters
	
	/**
	 * if parameter is between 0 and 23 (inclusive),
	 * set hour to the parameter, else set hour to 0
	 */
	public void setHour(int h)  {
		if(h < 0)
			hour = 0;
		else if(h > 23)
			hour = 23;
		else
			hour = h;
	}

	/**
	 * if parameter is between 0 and 59 (inclusive),
	 * set minute to the parameter, else set minute to 0
	 */
	public void setMinute(int m)  {
		if(m < 0)
			minute = 0;
		else if(m > 59)
			minute = 59;
		else
			minute = m;	
	}

	/**
	 * if parameter is between 0 and 59 (inclusive),
	 * set second to the parameter, else set second to 0
	 */
	public void setSecond(int s) {
		if(s < 0)
			second = 0;
		else if(s > 59)
			second = 59;
		else
			second = s;		
	}
	
	//getters
	
	/**
	 * return hour
	 */
	public int getHour() {
		return hour;
	}

	/**
	 * return minute
	 */
	public int getMinute() {
		return minute;
	}

	/**
	 * return second
	 */
	public int getSecond() {
		return second;
	}
	
	/**
	 * set data members to 0 USING THE SETTERS
	 */
	public Time() {
		setHour(0);
		setMinute(0);
		setSecond(0);
	}
	
	/**
	 * set data members to values passed USING THE SETTERS
	 * @param h
	 * @param m
	 * @param s
	 */
	public Time(int h, int m, int s) {
		setHour(h);
		setMinute(m);
		setSecond(s);
	}

	@Override
	public String toString() {
		String hh = (hour%12)+"";
		String mm = minute+"";
		String ss = second+"";
		
		if(hh.length() == 1)
			hh = "0"+hh;
		if(mm.length() == 1)
			mm = "0"+mm;
		if(ss.length() == 1)
			ss = "0"+ss;
		
		String result = hh+":"+mm+":"+ss;
		if(hour < 12) 
			return result+" am";
		else 
			return result+" pm";
	}	

	/**
	 * when you frequently need to display an object
	 */
	public void display() {
		// TODO Auto-generated method stub
		System.out.println(toString()); //calls toString
	}
}
