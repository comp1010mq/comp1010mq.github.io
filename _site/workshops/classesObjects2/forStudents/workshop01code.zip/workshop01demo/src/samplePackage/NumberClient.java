package samplePackage;

import java.util.Random;

public class NumberClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random r = new Random();
		int n = r.nextInt(30) + 5; //n is between 5+0 (5) and 5+29 (34)
		int roundOff = (n + 2)/5*5;
		System.out.println(n+ " rounded off to nearest multiple of 5 = "+roundOff);
	}

}
