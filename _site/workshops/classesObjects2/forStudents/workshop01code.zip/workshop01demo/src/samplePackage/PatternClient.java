package samplePackage;

import java.util.Random;

public class PatternClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random r = new Random();
		int n = r.nextInt(10) + 5; //n is between 5+0 (5) and 5+9 (14)
		System.out.println("n = "+n);
		for(int i=0; i < n; i++) {
			for(int k=0; k<n-i; k++) {
				System.out.print(" ");
			}
			for(int k=0; k<2*i+1; k++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

}
