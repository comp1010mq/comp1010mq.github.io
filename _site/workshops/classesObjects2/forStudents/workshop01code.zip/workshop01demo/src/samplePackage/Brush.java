package samplePackage;
import processing.core.*; 

public class Brush extends PApplet {

	private static final long serialVersionUID = 1L;

	public void setup() {
		background(0);
	}

	public void draw() {
	}

	public void mouseDragged() {
		stroke(240,240,80);
		strokeWeight(3);
		line(pmouseX,pmouseY,mouseX,mouseY);
	}

	public void keyPressed() {
		background(0);
	}
	
	public void settings() {  
		size(400, 300); 
	}
	
	static public void main(String[] passedArgs) {
		String[] appletArgs = new String[] { "brush" };
		if (passedArgs != null) {
			PApplet.main(concat(appletArgs, passedArgs));
		} else {
			PApplet.main(appletArgs);
		}
	}
}
