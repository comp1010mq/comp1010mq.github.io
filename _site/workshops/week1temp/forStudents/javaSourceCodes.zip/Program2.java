public class Program2 {
	public static void main(String[] args) {
		int n = 6;
		int result = 0;
		System.out.println("n = "+n);
		for(int i=1, i < n, i++) {
			result = result + i
		}
		}
		}
		System.out.println("sum of integers from 1 to "n": "+result);
	}
}