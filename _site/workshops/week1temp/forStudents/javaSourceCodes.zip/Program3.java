public class Program3 {
	public static void main(String[] args) {
        String name = "insert your name";
 		System.out.println("Hello, "+ name + "!");
	}
}