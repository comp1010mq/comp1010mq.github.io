

public class MainTask {
	/**
	 * 
	 * @param arr
	 * @return true if all the items of array arr are negative (less than 0), false otherwise.
	 * note, return true if array arr has no items (it's empty)
	 */
	public static boolean onlyNegatives(double[] arr) {
		return false; //to be completed
	}

	public static void main(String[] args) {
		/*
		 * 
		 * DO NOT MODIFY THE CONTENTS OF main
		 * 
		 */


		double[] a1 = {-1.5, -2.5, -3.5};
		System.out.println(onlyNegatives(a1)); //should be true

		double[] a2 = {-1.5, 0, -3.5};
		System.out.println(onlyNegatives(a2)); //should be false

		double[] a3 = {1.5, 2.5, 3.5};
		System.out.println(onlyNegatives(a3)); //should be false

		double[] a4 = {};
		System.out.println(onlyNegatives(a4)); //should be true

		double[] a5 = {-1.5, -2.5, 3.5};
		System.out.println(onlyNegatives(a5)); //should be false

		double[] a6 = {1.5, -2.5, -3.5};
		System.out.println(onlyNegatives(a6)); //should be false
	}
}
