import java.util.Arrays;

public class Buggy {

	public static void main(String[] args) {
		int[] a = {10, 70, 20, 90};
		int result = 1;
		for(int i=1; i < a.length; i++) {
			result = result + i;
		}
		System.out.println("Sum of all items of "+Arrays.toString(a)+" is "+result); //should be 190
	}

}
