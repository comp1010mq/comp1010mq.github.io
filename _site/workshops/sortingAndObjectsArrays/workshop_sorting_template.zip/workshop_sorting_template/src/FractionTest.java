
import static org.junit.Assert.*;

import org.junit.Test;

public class FractionTest {

	@Test
	public void testCompareTo() {
		Fraction f1 = new Fraction(8, 10);
		Fraction f2 = new Fraction(10, 8);
		assertEquals(-1, f1.compareTo(f2));
		assertEquals(1, f2.compareTo(f1));
		Fraction f3 = new Fraction(20, 16);
		assertEquals(0, f2.compareTo(f3));
		assertEquals(0, f3.compareTo(f2));			
	}

}
