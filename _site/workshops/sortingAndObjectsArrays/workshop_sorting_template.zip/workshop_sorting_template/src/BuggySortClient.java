import java.util.Arrays;

public class BuggySortClient {
	public static void main(String[] args) {
		int[] a = {1,7,2,9,8,3};
		Buggy.selectionSortBuggy(a);
		System.out.println(Arrays.toString(a));
	}
}
