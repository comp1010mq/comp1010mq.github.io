
public class Buggy {
	public static void selectionSortBuggy(int[] arr) {
		if(arr == null)
			return; //nothing to do
			
		for(int i=0; i < arr.length - 1; i++) {
			int minIndex = smallestItemIndex(arr, i);
			
			int first = arr[i];
			int second = arr[minIndex];
			
			int temp = first;
			first = temp;
			temp = second;
		}
	}

	/**
	returns the index of the smallest item in the array,
	starting at index startIndex
	*/
	public static int smallestItemIndex(int[] a, int startIndex) {
		if(a == null || startIndex < 0 || startIndex >= a.length)
			return -1;
		int result = startIndex;
		for(int i = startIndex + 1; i < a.length; i++)
			if(a[i] < a[result])
				result = i;
		return result;
	}
}
