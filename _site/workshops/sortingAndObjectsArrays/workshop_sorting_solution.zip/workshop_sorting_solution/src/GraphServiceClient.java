

public class GraphServiceClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(GraphService.isValid(null));
		System.out.println(GraphService.isValid(new int[]{}));
		System.out.println(GraphService.isValid(new int[]{4}));
		System.out.println(GraphService.isValid(new int[]{1,1,1,1,1}));
		System.out.println(GraphService.isValid(new int[]{1,1,1,1,2}));
		System.out.println(GraphService.isValid(new int[]{1,5,1,1,2}));
		System.out.println(GraphService.isValid(new int[]{10,1,1,1,1,1,1,1,1,1,1,1,1}));
		System.out.println(GraphService.isValid(new int[]{7,7,7,7,7,7,7,7}));
			
		
	}

}
