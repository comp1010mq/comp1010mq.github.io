package comp125;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class SortServiceTest {
	private Fraction[] myFractions;
	private Fraction[] yourFractions;

	@Before
	public void setupTests() {
		int[] nums = {5, 10, 2, 100, 6};
		int[] dens = {2, 20, 5, 100, 5};
		myFractions = new Fraction[5];
		for(int i=0; i<myFractions.length; i++) {
			myFractions[i] = new Fraction(nums[i], dens[i]);
		}
		
		yourFractions = new Fraction[5];
		for(int i=0; i<yourFractions.length; i++) {
			yourFractions[i] = new Fraction(i+1, i+2);
		}
	}
	
	@Test
	public void testIsAscendingSorted() {
		assertFalse(SortService.isAscendingSorted(null));
		assertFalse(SortService.isAscendingSorted(myFractions));
		assertTrue(SortService.isAscendingSorted(yourFractions));
		assertTrue(SortService.isAscendingSorted(new Fraction[0]));
		assertTrue(SortService.isAscendingSorted(new Fraction[1]));
	}

	@Test
	public void testSort() {
		assertFalse(SortService.isAscendingSorted(myFractions));
		SortService.sort(myFractions);
		assertTrue(SortService.isAscendingSorted(myFractions));
	}
	
	@Test
	/**
	 * should fail
	 */
	public void testBuggySort() {
		assertFalse(SortService.isAscendingSorted(myFractions));
		SortService.buggySort(myFractions);
		assertTrue(SortService.isAscendingSorted(myFractions));
	}
	
	@Test
	public void testSecondaySort() {
		assertFalse(SortService.isAscendingSorted(myFractions));
		SortService.secondarySort(myFractions);
		FractionArrayService.display(myFractions);
		assertTrue(SortService.isAscendingSorted(myFractions));
	}

}
