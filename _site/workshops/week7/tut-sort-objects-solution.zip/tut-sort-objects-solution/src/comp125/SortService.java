package comp125;

public class SortService {

	public static boolean isAscendingSorted(Fraction[] fractions) {
		if(fractions == null)
			return false;
		for(int i=0; i<fractions.length-1; i++) {
			Fraction first = fractions[i];
			Fraction second = fractions[i+1];
			if(first.compareTo(second) == 1) //violates ascending order sorting rule
				return false;
		}
		return true;
	}
	
	//bubble sort
	public static void sort(Fraction[] fractions) {
		for(int i=0; i<fractions.length; i++) {
			for(int k=0; k<fractions.length-1-i; k++) {
				if(fractions[k].compareTo(fractions[k+1]) == 1) {
					Fraction temp = fractions[k];
					fractions[k] = fractions[k+1];
					fractions[k+1] = temp;
					/*
					 * note that we are updated references to which items 
					 * of the array refer to! draw a memory diagram of the array
					 * to understand this clearly
					 */
				}
			}
		}
	}
	
	
	//bubble sort
	public static void buggySort(Fraction[] fractions) {
		for(int i=0; i<fractions.length; i++) {
			for(int k=0; k<fractions.length-1-i; k++) {
				Fraction first = fractions[k];
				Fraction second = fractions[k+1];
				
				if(first.compareTo(second) == 1) {
					Fraction temp = first;
					first = second;
					second = temp;
				}
			}
		}
	}
	
	public static void secondarySort(Fraction[] fractions) {
		if(fractions == null)
			return;
		
		Fraction[] temp = new Fraction[fractions.length];
		
		for(int itemsAdded = 0; itemsAdded < fractions.length-1; itemsAdded++) {
			putInPlace(temp, fractions[itemsAdded], itemsAdded);
		}
		
		fractions = temp;
	}

	public static void putInPlace(Fraction[] target, Fraction item, int count) {
		if(count == 0) {
			target[0] = item;
			return;
		}
		int i = 0;
		for(; i<count; i++)
			if(target[i].compareTo(item) == 1)
				break;
		
		for(int k=count; k>i; k--)
			target[k+1] = target[k];
		
		target[i] = item;
	}
}

