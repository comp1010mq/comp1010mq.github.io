package comp125;

import java.util.Random;

public class FractionArrayService {

	public static Fraction[] generateArray(int n) {
		if(n < 0)
			return null;
		
		Fraction[] result = new Fraction[n];
		
		Random r = new Random();
		
		for(int i=0; i<result.length; i++) {
			int num = r.nextInt(100);
			int den = r.nextInt(100) + 1;
			result[i] = new Fraction(num, den);
		}
		
		return result;	
	}

	public static Fraction[] generateSortedArray(int n) {
		if(n < 0)
			return null;
		
		Fraction[] result = new Fraction[n];
		
		for(int i=0; i<result.length; i++)
			result[i] = new Fraction(i+1, i+2);
		
		return result;	
	}
	
	public static void display(Fraction[] fractions) {
		for(int i=0; i<fractions.length; i++)
			System.out.println(fractions[i]);
		System.out.println();
	}
}
