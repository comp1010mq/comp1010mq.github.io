package comp125;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class FractionArrayServiceTest {
	private Fraction[] myFractions;
	private Fraction[] yourFractions;

	@Before
	public void setupTests() {
		int[] nums = {5, 10, 2, 100, 6};
		int[] dens = {2, 20, 5, 100, 5};
		myFractions = new Fraction[5];
		for(int i=0; i<myFractions.length; i++) {
			myFractions[i] = new Fraction(nums[i], dens[i]);
		}
		
		yourFractions = new Fraction[5];
		for(int i=0; i<yourFractions.length; i++) {
			yourFractions[i] = new Fraction(i+1, i+2);
		}
	}
	
	@Test
	public void testIsAscendingSorted() {
		assertFalse(FractionArrayService.isAscendingSorted(null));
		assertFalse(FractionArrayService.isAscendingSorted(myFractions));
		assertTrue(FractionArrayService.isAscendingSorted(yourFractions));
		assertTrue(FractionArrayService.isAscendingSorted(new Fraction[0]));
		assertTrue(FractionArrayService.isAscendingSorted(new Fraction[1]));
	}

	@Test
	public void testBubbleSort() {
		assertFalse(FractionArrayService.isAscendingSorted(myFractions));
		FractionArrayService.bubbleSort(myFractions);
		assertTrue(FractionArrayService.isAscendingSorted(myFractions));
	}
	
	@Test
	/**
	 * should fail
	 */
	public void testBuggySort() {
		assertFalse(FractionArrayService.isAscendingSorted(myFractions));
		FractionArrayService.buggySort(myFractions);
		assertTrue(FractionArrayService.isAscendingSorted(myFractions));
	}
	
	@Test
	public void testSecondaySort() {
		assertFalse(FractionArrayService.isAscendingSorted(myFractions));
		FractionArrayService.secondarySort(myFractions);
		assertTrue(FractionArrayService.isAscendingSorted(myFractions));
	}
}
