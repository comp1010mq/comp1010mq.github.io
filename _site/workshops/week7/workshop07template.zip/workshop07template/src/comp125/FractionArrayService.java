package comp125;

import java.util.Random;

public class FractionArrayService {
	public static Fraction[] generateRandomArray(int n) {
		if(n < 0)
			return null;
		
		Fraction[] result = new Fraction[n];
		
		Random r = new Random();
		
		for(int i=0; i<result.length; i++) {
			int num = r.nextInt(100);
			int den = r.nextInt(100) + 1;
			result[i] = new Fraction(num, den);
		}
		
		return result;	
	}
	
	// Returns the array {1/2, 2/3, 3/4, ..., n/(n+1)}
	public static Fraction[] generateSortedArray(int n) {
		if(n < 0)
			return null;
		
		Fraction[] result = new Fraction[n];
		
		for(int i=0; i<result.length; i++)
			result[i] = new Fraction(i+1, i+2);
		
		return result;	
	}
	
	public static void display(Fraction[] fractions) {
		for(int i=0; i<fractions.length; i++)
			System.out.println(fractions[i]);
		System.out.println();
	}
	
	public static boolean isAscendingSorted(Fraction[] fractions) {
		if(fractions == null)
			return false;
		for(int i=0; i<fractions.length-1; i++) {
			Fraction first = fractions[i];
			Fraction second = fractions[i+1];
			if(first.compareTo(second) == 1) //violates ascending order sorting rule
				return false;
		}
		return true;
	}
	
	//bubble sort
	public static void bubbleSort(Fraction[] fractions) {
		for(int i=0; i<fractions.length; i++) {
			for(int k=0; k<fractions.length-1-i; k++) {
				//if an item at index k is more than that at index k+1
				if(fractions[k].compareTo(fractions[k+1]) > 0) {
					//swap them so the new item at index k
					//is NOT more than the item at index k+1
					Fraction temp = fractions[k];
					fractions[k] = fractions[k+1];
					fractions[k+1] = temp;
					/*
					 * note that we are updated references to which items 
					 * of the array refer to! draw a memory diagram of the array
					 * to understand this clearly
					 */
				}
			}
		}
	}
	
	
	//buggy bubble sort - identify issue
	public static void buggySort(Fraction[] fractions) {
		for(int i=0; i<fractions.length; i++) {
			for(int k=0; k<fractions.length-1-i; k++) {
				Fraction first = fractions[k];
				Fraction second = fractions[k+1];
				
				if(first.compareTo(second) == 1) {
					Fraction temp = first;
					first = second;
					second = temp;
				}
			}
		}
	}
	
	public static void secondarySort(Fraction[] fractions) {
		if(fractions == null)
			return;
		
		Fraction[] temp = new Fraction[fractions.length];
		
		for(int itemsAdded = 0; itemsAdded < fractions.length; itemsAdded++)
			putInPlace(temp, fractions[itemsAdded], itemsAdded);
		
		/*
		 * complete an important part over here. for hint,
		 * display temp array and fraction array individually
		 */
	}

	public static void putInPlace(Fraction[] target, Fraction item, int count) {
		if(count == 0) {
			target[0] = item;
			return;
		}
		
		int i = 0;
		for(; i<count; i++)
			if(target[i].compareTo(item) == 1)
				break;
		
		for(int k=count; k>i; k--)
			target[k] = target[k-1];
		
		target[i] = item;
	}
}

