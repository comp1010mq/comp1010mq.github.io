public class Marks {
	private double[] marks;
	//in this case, setter should be called only 
	//from the constructor, hence private

	private void setMarks(double[] m) {
		if(m == null)
			return;
		marks = new double[m.length];
		for(int i=0; i < m.length; i++)
			setMark(i, m[i]);
	}

	public void setMark(int idx, double mark) {
		if(idx < 0 || idx >= marks.length)
			return; //out of bounds
		if(mark < 0)
			marks[idx] = 0;
		else if(mark > 100)
			marks[idx] = 100;
		else 
			marks[idx] = mark;
	}

	public double getMark(int idx) {
		if(idx < 0 || idx >= marks.length)
			return 0; //out of bounds
		return marks[idx];
	}

	public Marks(double[] m) {
		if(m == null)
			return;
		setMarks(m);
	}
	
	public String toString() {
		String result = "Number of assessments: "+marks.length;
		for(int i=0; i < marks.length; i++)
			result = result + "\nMarks in assessment " + (i+1)+": " + marks[i];
		return result;
	}
}