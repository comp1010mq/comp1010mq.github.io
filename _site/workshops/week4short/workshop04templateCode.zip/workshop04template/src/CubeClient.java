public class CubeClient {
	public static void main(String[] args) {
		Cube c1 = new Cube(1.5);
		Cube c2 = new Cube(3.5);
		Cube c3 = new Cube(1.5);
		Cube c4 = new Cube(0.5);
		
		//note: errors will go away once you define compareTo
		//in Cube class
		int flag1 = c1.compareTo(c2); 
		int flag2 = c3.compareTo(c1);
		int flag3 = c4.compareTo(c3);
		
		System.out.println(flag1);
		System.out.println(flag2);
		System.out.println(flag3);
	}
}