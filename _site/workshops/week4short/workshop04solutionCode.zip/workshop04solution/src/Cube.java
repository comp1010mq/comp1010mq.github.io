public class Cube {
	private double side;
	
	public double getSide() {
		return side;
	}
	
	public void setSide(double side) {
		this.side = Math.max(0, side);
	}
	
	public Cube(double side) {
		setSide(side);
	}
	
	public double volume() {
		return side*side*side;
	}
	
	public int compareTo(Cube other) {
		if(this.side > other.side)
			return 1;
		if(this.side < other.side)
			return -1;
		return 0;
	}
}