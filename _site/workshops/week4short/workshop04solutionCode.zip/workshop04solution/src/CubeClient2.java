public class CubeClient2 {
	public static void main(String[] args) {
		Cube c1 = new Cube(1.5);
		Cube c2 = new Cube(3.5);
		Cube c3 = c2;
		double s = c1.getSide() - 1;
		c2.setSide(s);
		System.out.println(c1.getSide());
		System.out.println(c2.getSide());
		System.out.println(c3.getSide());
	}
}