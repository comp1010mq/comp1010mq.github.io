import static org.junit.Assert.*;

import org.junit.Test;

public class SphereTest {

	@Test
	/**
	 * the expected values for radius = 1, 1.5 are taken from google
	 */
	public void testVolume() {
		Sphere s1 = new Sphere(0);
		Sphere s2 = new Sphere(1);
		Sphere s3 = new Sphere(1.5);
		assertEquals(0, s1.volume(), 0.01);
		assertEquals(4.19, s2.volume(), 0.01);
		assertEquals(14.14, s3.volume(), 0.01);
	}

	@Test
	/**
	 * implement this test to test for correctness of the surfaceArea() method from class Sphere
	 */
	public void testSurfaceArea() {
		Sphere s1 = new Sphere(0);
		Sphere s2 = new Sphere(1);
		Sphere s3 = new Sphere(1.5);
		assertEquals(0, s1.surfaceArea(), 0.01);
		assertEquals(12.57, s2.surfaceArea(), 0.01);
		assertEquals(28.27, s3.surfaceArea(), 0.01);
	}

}
