public class MarksClient {
	public static void main(String[] args) {
		double[] data = {78.5, 135.3, -61.8, 83.2};
		Marks myScores = new Marks(data);
		System.out.println(myScores);
	}
}