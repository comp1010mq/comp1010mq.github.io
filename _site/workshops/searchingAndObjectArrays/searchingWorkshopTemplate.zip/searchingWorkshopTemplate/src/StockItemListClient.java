

public class StockItemListClient {

	public static void main(String[] args) {

		StockItem[] items = generateStockItemArray(5);
		
		int maxTotalPriceIndex = getCostliestItemIndex(items);
		
		System.out.println("Item with most money invested is: "+items[maxTotalPriceIndex]);
	}

	public static int getCostliestItemIndex(StockItem[] items) {
		return 0; //to be completed
	}

	public static StockItem[] generateStockItemArray(int size) {
		return null; //to be completed
	}

}
