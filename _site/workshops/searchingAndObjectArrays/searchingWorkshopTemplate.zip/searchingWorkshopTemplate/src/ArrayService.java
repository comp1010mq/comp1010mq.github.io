

import java.util.Random;


public class ArrayService {
	public static int[] generate(int size, int low, int high) {
		Random r = new Random();
		int[] a = new int[size];
		for(int i=0; i<a.length; i++) {
			a[i] = low + r.nextInt(high-low+1);
		}
		return a;
	}

	public static int[] generateSortedArray(int size, int low, int high) {
		Random r = new Random();
		int[] a = new int[size];
		for(int i=0; i<a.length; i++) {
			if(i == 0)
				a[i] = low;
			else {
				int inc = r.nextInt(3);
				int value = a[i-1] + inc;
				if(value <= high)
					a[i] = value;
				else
					a[i] = high;
			}
		}
		return a;
	}

	public static void display(int[] b) {
		for(int i=0; i<b.length; i++) {
			if(i > 0 && i%10 == 0)
				System.out.println();
			System.out.print(b[i]+"\t");
		}
	}

	public static boolean isSorted(int[] data) {
		// TODO Auto-generated method stub
		for(int i=1; i<data.length; i++)
			if(data[i] < data[i-1])
				return false;
		return true;
	}

	public static int linearSearch(int[] data, int key) {
		return -1; //to be completed
	}

	/**
	 * 
	 * @param arr, ASSUMED to be in sorted order
	 * @param target
	 * @return
	 */
	public static int binarySearch(int[] arr, int target) {
		int first = 0; 
		int last = arr.length-1;
		while( first <= last ) {		
			int median = (first + last)/2;		
			if (target  == arr[median])
				return median;
			if (target < arr[median])
				last = median - 1; //left
			else
				first = median + 1; //right
		}
		return -1;
	}

	/**
	 * uses binarySearch if array a is sorted in ascending order, otherwise uses linearSearch
	 * @param item
	 * @return
	 */
	public static int search(int[] data, int item) {
		return -1; //to be completed
	}
}
