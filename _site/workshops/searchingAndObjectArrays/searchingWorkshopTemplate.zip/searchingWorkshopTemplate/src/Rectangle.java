public class Rectangle {
	private double width, height;

	public double area() {
		double result =  width * height;
		return result;
	}
	
	public double perimeter() {
		double result = 2*(width + height); 
		return result;
	}
	
	public double diagnol() {
		return Math.sqrt(width*width + height*height);
	}
	
	//public read methods (getters)
	public double getWidth() {
		return width;
	}

	public double getHeight() {
		return height;
	}

	//public write methods (setters)
	public void setWidth(double w) {
		if(w < 0) //naughty!
			w = 0;
		//w >= 0
		width = w;
	}

	public void setHeight(double h) {
		if(h < 0) 
			h = -h; //negating negative values, thereby making it positive
		//h >= 0
		height = h;
	}

	public Rectangle(double w, double h) {
		setWidth(w);
		setHeight(h);
	}

	public Rectangle(double s) {
		setWidth(s);
		setHeight(s);
	}

	public Rectangle() {
		setWidth(1);
		setHeight(1);
	}
	
	//copy constructor
	public Rectangle(Rectangle source) {
		setWidth(source.width);
		setHeight(source.height);
	}

	public boolean equals(Rectangle other) {
		if(this.area() == other.area())
			return true;
		else
			return false;
	}

	/**
	 * @return 1 if calling object is "more than" the parameter object
	 * -1 if calling object is "less than" the parameter object
	 * 0 if calling object and parameter object are the "same"
	 * 
	 * comparison criterion: area
	 */
	public int compareTo(Rectangle other) {
		if(this.area() > other.area())
			return 1;
		if(this.area() < other.area())
			return -1;
		return 0;
	}
	
	public boolean isSquare() {
		if(width == height)
			return true;
		else
			return false;
	}
}
