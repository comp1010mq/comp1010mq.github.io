

public class StockItem {
	private String name;
	private double price;
	private int quantity;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setPrice(double price) {
		this.price = Math.abs(price);
	}
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = Math.abs(quantity);
	}
	
	public StockItem(String n, double p, int q) {
		setName(n);
		setPrice(p);
		setQuantity(q);
	}
	
	public String toString() {
		return name+" priced at "+price+", quantity left "+quantity;
	}

	public double totalStockPrice() {
		// TODO Auto-generated method stub
		return price * quantity;
	}
	
	public int compareTo(StockItem other) {
		double total1 = this.totalStockPrice();
		double total2 = other.totalStockPrice();
		
		if(total1 > total2)
			return 1;
		if(total1 < total2)
			return -1;
		return 0;
	}	
}
