package timeComplexityJUnitProject;

public class TimeComplexityClient {

	public static void main(String[] args) {
		/*
		 * the following four statements are to set the four methods
		 * up in memory and not affect time comparisons
		 */
		TimeComplexityService.searchVersion1(new int[]{1}, 1);
		TimeComplexityService.searchVersion2(new int[]{1}, 1);
		TimeComplexityService.sumVersion1(1);
		TimeComplexityService.sumVersion2(1);
		
		long startTime, timeElapsed;
		
		System.out.println("\t\t Version 1 \t Version 2");
		System.out.println("search algorithm comparison");
		for(int size = 10; size <= 10000; size*=10) {
			System.out.print(size+" items\t\t");
			
			int[] a = new int[size];
			a[0] = 5; //array becomes {5, 0, 0, 0, ...}
			
			startTime = System.nanoTime();
			int result = TimeComplexityService.searchVersion1(a, 5);
			timeElapsed = System.nanoTime() - startTime;
			
			System.out.print(timeElapsed+"\t\t");
			startTime = System.nanoTime();
			result = TimeComplexityService.searchVersion2(a, 5);
			timeElapsed = System.nanoTime() - startTime;
			System.out.println(timeElapsed);
		}
		
		System.out.println();
		System.out.println("sum algorithm comparison");
		for(int n = 1; n <= 32768; n*=2) {
			System.out.print("n = "+n+"\t\t");
			
			startTime = System.nanoTime();
			int result = TimeComplexityService.sumVersion1(n);
			timeElapsed = System.nanoTime() - startTime;
			
			System.out.print(timeElapsed+"\t\t");
			startTime = System.nanoTime();
			result = TimeComplexityService.sumVersion2(n);
			timeElapsed = System.nanoTime() - startTime;
			System.out.println(timeElapsed);
		}
	}
}
