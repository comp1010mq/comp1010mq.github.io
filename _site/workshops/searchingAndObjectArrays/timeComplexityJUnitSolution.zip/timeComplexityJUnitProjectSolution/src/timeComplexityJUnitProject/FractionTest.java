package timeComplexityJUnitProject;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class FractionTest {
	private Fraction f1, f2, f3, f4;

	@Before
	/**
	 * this method executes before each test method
	 * (basically it sets up the objects to be used
	 * in each method)
	 */
	public void beforeEachTest() {
		f1 = new Fraction(2, 6);
		f2 = new Fraction(8, 24);
		f3 = new Fraction(1000000, 3000000);
		f4 = new Fraction(156, 97);
	}

	@Test
	public void testSimplify() {
		f1.simplify();
		//should become 1/3
		assertEquals(1, f1.getNum());
		assertEquals(3, f1.getDen());

		f4.simplify();
		//stays the same
		assertEquals(156, f4.getNum());
		assertEquals(97, f4.getDen());
	}

	@Test
	public void testGetSimplified() {
		Fraction temp = f1.getSimplified();

		//temp should be 1/3
		assertEquals(1, temp.getNum());
		assertEquals(3, temp.getDen());

		//f1 shouldn't change
		assertEquals(2, f1.getNum());
		assertEquals(6, f1.getDen());
	}

	@Test
	public void testEqualsFraction() {
		assertTrue(f1.equals(f2));
		assertTrue(f1.equals(f3));
		assertTrue(f2.equals(f3));
		assertFalse(f1.equals(f4));
	}

	@Test
	public void testMultiply() {
		Fraction temp = f1.multiply(f2);
		assertEquals(16, temp.getNum());
		assertEquals(144, temp.getDen());
	}

	@Test
	public void testDivide() {
		Fraction temp = f1.divide(f2);
		assertEquals(48, temp.getNum());
		assertEquals(48, temp.getDen());
	}

	@Test
	public void testAdd() {
		Fraction temp = f1.add(f2);
		assertEquals(96, temp.getNum());
		assertEquals(144, temp.getDen());
	}

	@Test
	public void testSubtract() {
		Fraction temp = f1.subtract(f2);
		assertEquals(0, temp.getNum());
		assertEquals(144, temp.getDen());
	}

}
