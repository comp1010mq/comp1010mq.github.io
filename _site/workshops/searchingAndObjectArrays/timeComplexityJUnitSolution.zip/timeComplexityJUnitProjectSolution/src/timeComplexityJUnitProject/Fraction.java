package timeComplexityJUnitProject;

/**
 * encodes a fraction of the form num/den
 * for example 2/5 or 54/90 or 6/1
 * @author gauravgupta
 *
 */
public class Fraction {
	private int num, den;

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public int getDen() {
		return den;
	}

	public void setDen(int den) {
		if(den == 0)
			den = 1;
		else
			this.den = den;
	}

	public Fraction(int num, int den) {
		setNum(num);
		setDen(den);
	}
	
	/**
	 * when you want to simplify a fraction to irreducible form
	 * like 20 / 60 to 1 / 3
	 */
	public void simplify() {
		int gcd = getGcd();
		num/=gcd;
		den/=gcd;
	}
	
	/**
	 * when you want to return the simplified version without
	 * modifiying the fraction itself
	 * @return simplified fraction (irreducible).
	 */
	public Fraction getSimplified() {
		int gcd = getGcd();
		Fraction f = new Fraction(num/gcd, den/gcd);
		return f;
	}
	
	/**
	 * 
	 * @return greatest common divisor of numerator and denomenator
	 */
	private int getGcd() {
		int smaller = Math.min(num, den);
		for(int i=smaller; i > 1; i--)
			if(num%i == 0 && den%i == 0)
				return i;
		return 1;
	}
	
	/**
	 * @param other
	 * @return true if calling object and parameter object are the same.
	 * For example, 4/10 and 40/100 are equal but 4/10 and 41/100 are not.
	 * 
	 * Hint to correct: what happens when you divide a fraction by 
	 * another equal fraction? For eg., what is 2/8 divided by 10/40? 
	 */
	public boolean equals(Fraction other) {
		Fraction division = divide(other);
		if(division.num == division.den) 
			return true;
		else
			return false;
	}
	
	/**
	 * @param other
	 * @return the product of calling object and parameter object. For eg.,
	 * 2/8 * 3/5 = 6/40
	 */
	public Fraction multiply(Fraction other) {
		int n = num * other.num;
		int d = den * other.den;
		Fraction f = new Fraction(n, d);
		return f;
	}
	
	public Fraction divide(Fraction other) {
		int n = num * other.den;
		int d = den * other.num;
		Fraction f = new Fraction(n, d);
		return f;
	}
	
	/**
	 * DID NOT HAVE BUGS
	 * @param other
	 * @return sum of two fractions. For eg., 1/3 + 2/5 = 11/15
	 */
	public Fraction add(Fraction other) {
		int n = num * other.den + den * other.num;
		int d = den * other.den;
		Fraction f = new Fraction(n, d);
		return f;
	}
	
	/**
	 * HAD BUGS, REMOVED
	 * @param other
	 * @return difference between two fractions. For eg., 1/3 - 2/5 = -1/15
	 */
	public Fraction subtract(Fraction other) {
		int n = num * other.den - den * other.num;
		int d = den * other.den;
		Fraction f = new Fraction(n, d);
		return f;
	}
}
