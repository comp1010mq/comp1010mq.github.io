package timeComplexityJUnitProject;

public class TimeComplexityService {
	public static int searchVersion1(int[] a, int target) {
		if(a == null)
			return -1;
		
		int idx = -1;
		boolean found = false;
		
		for(int i=0; i < a.length; i++) {
			if(a[i] == target && found == false) {
				idx = i;
				found = true;
			}
		}
		
		return idx;
	}
	
	public static int searchVersion2(int[] a, int target) {
		if(a == null)
			return -1;
		
		for(int i=0; i < a.length; i++) {
			if(a[i] == target) {
				 return i;
			}
		}
		
		return -1;
	}

	/**
	 * 
	 * @param n
	 * @return 1 + 2 + ... (n - 1) + n
	 */
	public static int sumVersion1(int n) {
		int result = 0;
		for(int i=1; i<=n; i++)
			result+=i;
		return result;
	}
	
	/**
	 * 
	 * @param n
	 * @return 1 + 2 + ... (n - 1) + n
	 */
	public static int sumVersion2(int n) {
		return n * (n + 1)/2;
	}
	
	public static int meFailEnglishThatsUnpossible(int n) {
		int result = 1;
		for(int i=1; i<=n; i++) {
			for(int k=1; k<=n; k++) {
				result++;
			}
		}
		return result;
	}
	
	public static void foo1(int n) {
		for(int i=1; i <= n; i*=2) {
			//move along, nothing to see here			
		}
	}
	
	public static void foo2(int n) {
		for(int i=1; i <= n; i+=3) {
			//move along, nothing to see here			
		}
	}
	
	public static void foo3(int n) {
		for(int i=1; i <= n*n; i+=3) {
			//move along, nothing to see here
		}
	}
}
