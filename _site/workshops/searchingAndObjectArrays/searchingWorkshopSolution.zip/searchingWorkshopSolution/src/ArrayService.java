

import java.util.Random;


public class ArrayService {
	public static int[] generate(int size, int low, int high) {
		Random r = new Random();
		int[] a = new int[size];
		for(int i=0; i<a.length; i++) {
			a[i] = low + r.nextInt(high-low+1);
		}
		return a;
	}

	public static int[] generateSortedArray(int size, int low, int high) {
		Random r = new Random();
		int[] a = new int[size];
		for(int i=0; i<a.length; i++) {
			if(i == 0)
				a[i] = low;
			else {
				int inc = r.nextInt(3);
				int value = a[i-1] + inc;
				if(value <= high)
					a[i] = value;
				else
					a[i] = high;
			}
		}
		return a;
	}

	public static void display(int[] b) {
		for(int i=0; i<b.length; i++) {
			if(i > 0 && i%10 == 0)
				System.out.println();
			System.out.print(b[i]+"\t");
		}
	}

	public static boolean isSorted(int[] data) {
		// TODO Auto-generated method stub
		for(int i=1; i<data.length; i++)
			if(data[i] < data[i-1])
				return false;
		return true;
	}

	public static int linearSearch(int[] arr, int target) {
		if(arr == null)
			return -1; //not found

		for(int i=0; i < arr.length; i++)
			if(arr[i] == target) //found!!!
				return i; //return index of the item

		return -1;
	}

	/**
	 * 
	 * @param arr, ASSUMED to be in sorted order
	 * @param target
	 * @return
	 */
	public static int binarySearch(int[] arr, int target) {
		if(arr == null)
			return -1; //not found

		//set search space
		int first = 0; //first valid index
		int last = arr.length - 1; //last valid index

		while(first <= last) { //till some search space is not yet exhausted
			int median = (first + last)/2; //find median item
			//REMEMBER THE BRACKETS

			if(target == arr[median]) //if median item is your item
				return median; //return its location

			if(target < arr[median]) //if it exists, it's in the left half
				last = median - 1; //only consider items on left of median

			if(target  > arr[median]) //if it exists, it's in the right half
				first = median + 1; //only consider items on right of median
		}

		return -1; //exhausted search space - return -1
	}
	
	/**
	 * 
	 * @param arr, ASSUMED to be in descending sorted order
	 * @param target
	 * @return
	 */
	public static int binarySearchDescending(int[] arr, int target) {
		if(arr == null)
			return -1; //not found

		//set search space
		int first = 0; //first valid index
		int last = arr.length - 1; //last valid index

		while(first <= last) { //till some search space is not yet exhausted
			int median = (first + last)/2; //find median item
			//REMEMBER THE BRACKETS

			if(target == arr[median]) //if median item is your item
				return median; //return its location

			if(target > arr[median]) //if it exists, it's in the left half
				last = median - 1; //only consider items on left of median

			if(target  < arr[median]) //if it exists, it's in the right half
				first = median + 1; //only consider items on right of median
		}

		return -1; //exhausted search space - return -1
	}
	
	/**
	 * 
	 * @param arr, ASSUMED to be in sorted order
	 * @param target
	 * @return
	 */
	public static int binarySearchDescending(Rectangle[] arr, Rectangle target) {
		if(arr == null)
			return -1; //not found

		//set search space
		int first = 0; //first valid index
		int last = arr.length - 1; //last valid index

		while(first <= last) { //till some search space is not yet exhausted
			int median = (first + last)/2; //find median item
			//REMEMBER THE BRACKETS

			if(target.compareTo(arr[median]) == 0) //if median item is your item
				return median; //return its location

			if(target.compareTo(arr[median]) < 0) //if it exists, it's in the left half
				last = median - 1; //only consider items on left of median

			if(target.compareTo(arr[median]) > 0) //if it exists, it's in the right half
				first = median + 1; //only consider items on right of median
		}

		return -1; //exhausted search space - return -1
	}
	

	/**
	 * uses binarySearch if array a is sorted in ascending order, otherwise uses linearSearch
	 * @param item
	 * @return
	 */
	public static int search(int[] data, int item) {
		if(isSorted(data))
			return binarySearch(data, item);
		else
			return linearSearch(data, item);
	}
}
