

public class StockItemListClient {

	public static void main(String[] args) {

		StockItem[] items = generateStockItemArray(5);
		
		int maxTotalPriceIndex = getCostliestItemIndex(items);
		
		System.out.println("Item with most money invested is: "+items[maxTotalPriceIndex]);
	}

	public static int getCostliestItemIndex(StockItem[] items) {
		int result = 0;
		
		for(int i=1; i < items.length; i++)
			if(items[i].compareTo(items[result]) > 0)
				result = i;
		return result;
	}

	public static StockItem[] generateStockItemArray(int size) {
		StockItem[] result = new StockItem[size];

		for(int i=0; i < result.length; i++) {
			double up = 2*i + 2;
			int q = 2*i - 8;
			result[i] = new StockItem("Item "+(i+1), up, q);
			System.out.println(result[i]);
		}
		return result;
	}

}
