import java.util.Random;

public class DiceRollRecord {
	private int[] log;
	
	public DiceRollRecord(int n) {
		log = new int[Math.max(0, n)];
		Random rand = new Random();
		for(int i=0; i < log.length; i++) {
			log[i] = 1 + rand.nextInt(6); 
		}
	}
	
	public double average() {
		if(log.length == 0) {
			return 0;
		}
		int total = 0;
		for(int i=0; i < log.length; i++) {
			total+=log[i];
		}
		return total * 1.0 / log.length;
	}
}
