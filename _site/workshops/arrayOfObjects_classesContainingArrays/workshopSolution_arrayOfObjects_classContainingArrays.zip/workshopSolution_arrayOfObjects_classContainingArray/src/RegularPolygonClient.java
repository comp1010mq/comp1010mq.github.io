import java.util.Random;

public class RegularPolygonClient {
	public static void main(String[] args) {
		Random rand = new Random();
		RegularPolygon[] items = new RegularPolygon[100];
		for(int i=0; i < items.length; i++) {
			int n = 3 + rand.nextInt(8);
			double s = 1 + (0.5 * (rand.nextInt(39)));
			items[i] = new RegularPolygon(n, s);
			if(items[i].area() > 50) {
				System.out.println(items[i]);
			}
		}
	}
}