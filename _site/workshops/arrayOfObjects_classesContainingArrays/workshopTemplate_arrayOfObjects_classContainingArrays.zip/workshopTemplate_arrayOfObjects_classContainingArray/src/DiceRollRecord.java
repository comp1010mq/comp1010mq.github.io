import java.util.Random;

public class DiceRollRecord {
	private int[] log;
	
	public DiceRollRecord(int n) {
		/*
		simulate 0 or n, whichever is higher, dice rolls, 
		storing the outcomes in the array log. 
		For example, 
		if n = 5, log should become
		either {1, 6, 3, 2, 5} or 
		{6, 1, 1, 1, 3}, and so on,
		and if n = -3, 
		log would be {} (empty array)
		*/ 
	}
	
	/**
	 * @return average roll
	 * (return 0 if log is empty)
	 * For example, 
	 * if log = {3, 1, 5, 2}, return 3.75
	 */
	public double average() {
		return 0; //to be completed
	}
}
