import java.util.Random;

public class RegularPolygonClient {
	public static void main(String[] args) {
		Random rand = new Random();
		//WRITE YOUR CODE HERE
	}
}