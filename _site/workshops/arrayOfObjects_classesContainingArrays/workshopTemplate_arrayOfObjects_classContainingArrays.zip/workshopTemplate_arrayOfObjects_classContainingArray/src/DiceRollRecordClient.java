public class DiceRollRecordClient {
	public static void main(String[] args) {
		DiceRollRecord myRecord = new DiceRollRecord(500);
		System.out.println(myRecord.average());
	}
}