public class RegularPolygon {
	private int numberOfSides;
	private double sideLength;
	
	public void setNumberOfSides(int n) {
		numberOfSides = Math.max(3, n);
	}
	
	public void setSideLength(double s) {
		sideLength = Math.abs(s);
	}
	
	public int getNumberOfSides() {
		return numberOfSides;
	}
	
	public double getSideLength() {
		return sideLength;
	}
	
	public RegularPolygon(int a, double b) {
		setNumberOfSides(a);
		setSideLength(b);
	}
	
	public double area() {
		double a = sideLength*sideLength*numberOfSides;
		return a/(4*Math.atan(180.0/numberOfSides));
	}
	
	public String toString() {
		return 	numberOfSides + 
			" sides, each of length " +
			sideLength;
	}
}	