package comp125;

import java.util.Scanner;

public class StringTheory {
	/**
	 *	This helping method has two parameters, a String and a char.
	 *	It returns the number of occurrences of the char in the String. 
	 */
	public static int countOccurrences(String aString, char ch) {
		/*
		 * 
		 * TO BE COMPLETED
		 * 
		 */
		return 0; //default value so as to not get runtime error. get rid of this before writing your code
	}
	
	@SuppressWarnings({ "resource", "unused" })
	public static void main(String[] args) {
		//program execution begins at this point
		
		//the following five statements contain calls to method countOccurrences
		System.out.println("'a' occurs "+countOccurrences("Hallelujah", 'a')+" times in Hallelujah"); //expected value 2
		System.out.println("'A' occurs "+countOccurrences("Hallelujah", 'A')+" times in Hallelujah"); //expected value 0
		System.out.println("'h' occurs "+countOccurrences("Hallelujah", 'h')+" times in Hallelujah"); //expected value 1
		System.out.println("'H' occurs "+countOccurrences("Hallelujah", 'H')+" times in Hallelujah"); //expected value 1
		System.out.println("'x' occurs "+countOccurrences("Hallelujah", 'x')+" times in Hallelujah"); //expected value 0
		
		//the following program section inputs a String and a char from the user
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter a String: ");
		String s = keyboard.next();
		System.out.print("Enter a character that you wish to count in "+s+": ");
		String token = keyboard.next(); //get a word from the user
		char ch = token.charAt(0); //and use the first char of that word as the target char
		
		/*
		 * 
		 * TO BE COMPLETED
		 * 
		 * add a piece of code to display the number of times char ch occurs in String s
		 * 
		 */
	}
}
