package comp125;

public class AssessedTask {
	/**
	 * Worth 50%
	 * @param n
	 * @return true if the square root of n is an integer
	 */
	public static boolean isPerfectSquare(int n) {
		return false; //TO BE COMPLETED
	}
	
	/**
	 * 
	 * @param n
	 * @param p
	 * @return number of times n is divisible by p
	 */
	public static int timesDivisible(int n, int p) {
		return 0; //TO BE COMPLETED
	}
	
	/**
	 * Advanced: Worth 15%
	 * @param ch containing at least 1 character
	 * @return a String containing all characters in passed array
	 * in the order of occurrence
	 */
	public static String arrayToString(char[] ch){
		return null; //TO BE COMPLETED
	}
	
	public static void main(String[] args) {
		/*
		 * 
		 * DO NOT MODIFY THE CONTENTS OF main
		 * 
		 */
		
		System.out.println(isPerfectSquare(25)); //should be true
		System.out.println(isPerfectSquare(5)); //should be false
		
		System.out.println(timesDivisible(120, 2)); //should be 3
		System.out.println(timesDivisible(120, 7)); //should be 0
		System.out.println(timesDivisible(729, 3)); //should be 6
		
		String str = arrayToString(new char[]{'h', 'e', 'l', 'l', 'o'});
		System.out.println(str); //should be "hello"
	}
}
