package comp125;

public class Ratios {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double distance1 = 100;
		double time1 = 42.5;
		
		double distance2 = 314.15; 
		/**
		 * assuming time is proportional to distance, compute
		 * time taken to travel distance2 and display it on the console
		 */
	}

}
