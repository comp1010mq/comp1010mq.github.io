package comp125;

public class Buggy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 5;
		int factorial = 0;
		for(int i = 1; i < n; i++) {
			factorial*=i;
		}
		System.out.println(factorial);
	}

}
