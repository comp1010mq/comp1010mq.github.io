package comp125;

public class Buggy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 5;
		int factorial = 1; //earlier value 0 was incorrect
		for(int i = 1; i <= n; i++) { //earlier expression i<n was incorrect
			factorial*=i;
		}
		System.out.println(factorial);
	}

}
