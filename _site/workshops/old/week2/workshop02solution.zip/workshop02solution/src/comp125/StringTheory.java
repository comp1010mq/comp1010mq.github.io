package comp125;

import java.util.Scanner;

public class StringTheory {
	public static int countOccurrences(String aString, char ch) {
		int count = 0;

		for(int i=0; i<aString.length(); i++) //for each character
			if(aString.charAt(i) == ch) //found a match
				count++; //increase number of occurrences by 1
		
		return count;
	}
	
	/**
	 * additional task A
	 */
	public static char mostFrequentCharacter(String s) {
		if(s == null || s.length() == 0) //uninstantiated or empty
			return (char)0;
		
		char maxChar = s.charAt(0);
		int maxOcc = countOccurrences(s, maxChar);
		
		for(int i=1; i<s.length(); i++) {
			int iOcc = countOccurrences(s, s.charAt(i));
			if(iOcc > maxOcc) {
				maxChar = s.charAt(i);
				maxOcc = iOcc;
			}
		}
		
		return maxChar;
	}
	
	/**
	 * additional task B
	 */
	public static String mostFrequentCharacters(String s) {
		if(s == null || s.length() == 0) //uninstantiated or empty
			return "";
		
		int maxOcc = countOccurrences(s, s.charAt(0));
		
		for(int i=1; i<s.length(); i++) {
			int iOcc = countOccurrences(s, s.charAt(i));
			if(iOcc > maxOcc) {
				maxOcc = iOcc;
			}
		}
		
		String result = "";
		
		for(int i=0; i<s.length(); i++) {
			int iOcc = countOccurrences(s, s.charAt(i));
			if(iOcc == maxOcc && result.indexOf(s.charAt(i)) < 0) {
				result = result + s.charAt(i);
			}
		}
		
		return result;
	}

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub		
		System.out.println("'a' occurs "+countOccurrences("Hallelujah", 'a')+" times in Hallelujah"); //2
		System.out.println("'A' occurs "+countOccurrences("Hallelujah", 'A')+" times in Hallelujah"); //0
		System.out.println("'h' occurs "+countOccurrences("Hallelujah", 'h')+" times in Hallelujah"); //1
		System.out.println("'H' occurs "+countOccurrences("Hallelujah", 'H')+" times in Hallelujah"); //1
		System.out.println("'x' occurs "+countOccurrences("Hallelujah", 'x')+" times in Hallelujah"); //0

		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter a String: ");
		String s = keyboard.next();
		System.out.print("Enter a character that you wish to count in "+s+": ");
		String token = keyboard.next(); //get a word from the user
		char ch = token.charAt(0); //and use the first char of that word as the target char

		int count = countOccurrences(s, ch);
		System.out.println(ch+" occurs "+count+" times in "+s);

		//additional tasks client code
		System.out.println("Most frequent character in \"abysmal\": "+mostFrequentCharacter("abysmal"));
		System.out.println("Most frequent character in \"surreal\": "+mostFrequentCharacter("surreal"));

		System.out.println("Most frequent characters in \"abysmal\": "+mostFrequentCharacters("abysmal"));
		System.out.println("Most frequent characters in \"fantastic\": "+mostFrequentCharacters("fantastic"));

	}

}
