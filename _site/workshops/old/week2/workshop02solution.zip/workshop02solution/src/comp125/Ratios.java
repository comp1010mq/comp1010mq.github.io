package comp125;

public class Ratios {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double distance1 = 100;
		double time1 = 42.5;
		
		double distance2 = 314.15; 
		double time2 = distance2 * time1 / distance1;
		
		System.out.println(time2);
	}

}
