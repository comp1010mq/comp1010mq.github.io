package comp125;

public class AssessedTask {

	public static int sum(int[] a) {
		//TO BE COMPLETED
		int total = 0;
		for(int i=0; i<a.length; i++)
			total+=a[i];
		return total;
	}
	
	public static int sumEven(int[] a) {
		//TO BE COMPLETED
		int total = 0;
		for(int i=0; i<a.length; i++)
			if(a[i]%2 == 0)
				total+=a[i];
		return total;
	}
	
	public static int countUnique(int[] a) {
		//TO BE COMPLETED
		int count = 0;
		for(int i=0; i < a.length; i++) {
			boolean dup = false;
			for(int k=0; k < a.length; k++)  
				if(i!=k && a[i] == a[k]) {
					dup = true;
					break;
				}
			if(dup == false)
				count++;
		}
		return count;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {3,1,4,1,5,9,2,6,5};
		System.out.println(sum(arr));
		System.out.println(sumEven(arr));
		System.out.println(countUnique(arr));		
	}
}
