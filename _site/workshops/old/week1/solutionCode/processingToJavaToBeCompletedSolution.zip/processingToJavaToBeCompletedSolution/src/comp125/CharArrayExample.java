package comp125;

import java.util.Random;

public class CharArrayExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rand = new Random();

		char[] ch = new char[10]; //create a character of 10 characters

		for(int i = 0; i < ch.length; i++) { //go through each item of the array
		  ch[i] = (char) ('a'+rand.nextInt(26)); //assign a lowercase alphabet to the item
		  System.out.println(ch[i]); //display the current item
		} 
		
		String s = "";
		for(int i = 0; i < ch.length; i++) //for each item
			s = s + ch[i]; //add the current item (a character) to the end of the string
		
		System.out.println("First to last construction: "+s);
		
		s = ""; //re-initialize s to empty string
		for(int i = 0; i < ch.length; i++) //for each item
			s = ch[i] + s; //add the current item (a character) to the BEGINNING of the string
		
		System.out.println("Last to first construction: "+s);
		
		int vowelCount = 0;
		
		for(int i = 0; i < ch.length; i++) //for each item
			if( ch[i] == 'a' || //if current item is a vowel
				ch[i] == 'e' ||
				ch[i] == 'i' ||
				ch[i] == 'o' ||
				ch[i] == 'u' )
				vowelCount++; //add 1 to vowelCount to reflect the occurrence
		
		System.out.println("Number of vowels: "+vowelCount);
	}
}
