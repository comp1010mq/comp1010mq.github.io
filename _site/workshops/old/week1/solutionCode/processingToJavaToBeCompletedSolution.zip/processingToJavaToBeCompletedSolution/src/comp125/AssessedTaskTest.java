package comp125;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class AssessedTaskTest {
	private int a[] = {3, 1, 8, 7}, b[] = {7}, c[] = {2, 1, 1, 4};
	
	@Before
	public void run() {
	}
	
	@Test
	public void testSum() {
		assertEquals(19, AssessedTask.sum(a));
		assertEquals(7, AssessedTask.sum(b));
		assertEquals(8, AssessedTask.sum(c));
	}

	@Test
	public void testSumEven() {
		assertEquals(8, AssessedTask.sumEven(a));
		assertEquals(0, AssessedTask.sumEven(b));
		assertEquals(6, AssessedTask.sumEven(c));
	}

	@Test
	public void testCountUnique() {
		assertEquals(4, AssessedTask.countUnique(a));
		assertEquals(1, AssessedTask.countUnique(b));
		assertEquals(2, AssessedTask.countUnique(c));

	}

}
