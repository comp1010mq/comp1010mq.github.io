package comp125;

import java.util.Random;

public class SupplementaryTask {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rand = new Random();

		int[] ages = new int[20];

		int total = 0;
		
		for(int i=0; i < ages.length; i++) {
			ages[i] = rand.nextInt(100) + 1;
			System.out.print(ages[i]+" ");
			total += ages[i];
		}
		
		System.out.println();
		System.out.println("Average age: "+total * 1.0 / ages.length);
		
		int count = 0;
		for(int i=0; i < ages.length; i++)
			if(ages[i] < 50)
				count++;

		System.out.println(count+" people under 50 years of age");

		
		boolean twoOld = false;
		
		for(int i=0; i < ages.length - 1; i++) {
			if(ages[i] > 80 && ages[i+1] > 80) {
				twoOld = true;
				break;
			}
		}
		
		System.out.println("Two consecutive people over 80: "+twoOld);

		System.out.print("Items occuring exactly once: \n");
		for(int i=0; i < ages.length; i++) {
			boolean dup = false;
			for(int k=i+1; k < ages.length; k++) {
				if(ages[i] == ages[k]) {
					dup = true;
					break; //no need checking subsequent items
					//as we know the item arr[i] has multiple occurrences
				}
			}
			if(dup == false)
				System.out.print(ages[i]+" ");
		}
		
		//following is just a sample exercise i was working on
		//and haven't included in the official workshop
		//but if you have reached so far, then there's no need to stop, is there :D
		
		int[] sample = {4,1,4,1,4,1,4,16,6,6,6,8,9,0,9};

		System.out.print("Items occuring more than once: \n");
		for(int i=0; i < sample.length; i++) {
			int first = -1, last = -1;
			for(int k=0; k < sample.length && first == -1; k++) 
				if(sample[k] == sample[i]) 
					first = k;
			
			for(int k=sample.length - 1; k >= 0 && last == -1; k--) 
				if(sample[k] == sample[i]) 
					last = k;
			
			if(first != last && first == i)
				System.out.print(sample[i]+" ");
		}
		
		
	}
}
