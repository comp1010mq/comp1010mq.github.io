package comp125;


public class AssessedTask {
	//worth 50% of the weekly mark
	public static int sum(int[] a) {
		return 0; //TO BE COMPLETED
	}
	
	//worth 35% of the weekly mark
	public static int sumEven(int[] a) {
		return 0; //TO BE COMPLETED
	}
	
	//HD level, worth 15% of the weekly mark
	public static int countUnique(int[] a) {
		return 0; //TO BE COMPLETED
	}
	
	public static void main(String[] args) {
		//DO NOT MODIFY ANY PART OF MAIN METHOD
		int[] arr = {3,1,4,1,5,9,2,6,5};
		System.out.println(sum(arr)); //should be 36
		System.out.println(sumEven(arr)); //should be 12
		System.out.println(countUnique(arr)); //should be 5
	}
}
