package comp125;

import java.util.Random;

public class SupplementaryTask {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Random rand = new Random();

		/*********************
		 * to be completed
		 ********************/
	}
}
