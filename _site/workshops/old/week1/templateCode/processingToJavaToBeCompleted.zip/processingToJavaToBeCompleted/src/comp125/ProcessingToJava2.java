package comp125;

import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

@SuppressWarnings({ "unused", "serial" })
public class ProcessingToJava2 extends PApplet {

	public void setup() {
		//to be completed
	}

	public void draw() {
		//to be completed
	}
	
	static public void main(String[] passedArgs) {
		//to be completed
	}
}
