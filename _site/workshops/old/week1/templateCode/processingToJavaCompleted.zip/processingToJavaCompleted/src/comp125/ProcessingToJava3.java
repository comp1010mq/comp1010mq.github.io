package comp125;

import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

@SuppressWarnings({ "unused", "serial" })
public class ProcessingToJava3 extends PApplet {

	boolean started = false;

	final float WEIGHT = 3.2f;

	public void setup() {
		size(400, 300);
		background(255);
		println("Lines drawn with weight "+WEIGHT);
	}

	public void draw() {
	}

	public void mouseClicked() {
		started = !started;
	}

	public void mouseMoved() {
		if(started) {
			stroke(255, 0, 0);
			strokeWeight(WEIGHT);
			//line from previous mouse location to current mouse location
			line(pmouseX, pmouseY, mouseX, mouseY); 
		}
	}
	static public void main(String[] passedArgs) {
		String[] appletArgs = new String[] { "ProcessingToJava3" };
		if (passedArgs != null) {
			PApplet.main(concat(appletArgs, passedArgs));
		} else {
			PApplet.main(appletArgs);
		}
	}
}
