package comp125;

import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

@SuppressWarnings({ "unused", "serial" })
public class ProcessingToJava5 extends PApplet {

	float[] x = new float[5];
	float[] y = new float[5];

	public void setup() {
		frameRate(1);
		size(403, 307);
		background(255);
		initialize(x, y);
	}

	public void draw() {
		background(255);
		for (int i=0; i<x.length-1; i++) {
			stroke(255 - (i+1)*255.0f/x.length);
			line(x[i], y[i], x[i+1], y[i+1]);
			x[i] = x[i+1];
			y[i] = y[i+1];
		}    

		x[x.length - 1] = random(width);
		y[y.length - 1] = random(height);
	}

	public void initialize(float[] a, float[] b) {
		for (int i=0; i<a.length; i++) {
			a[i] = random(width);
			b[i] = random(height);
		}
	}

	static public void main(String[] passedArgs) {
		String[] appletArgs = new String[] { "ProcessingToJava5" };
		if (passedArgs != null) {
			PApplet.main(concat(appletArgs, passedArgs));
		} else {
			PApplet.main(appletArgs);
		}
	}
}
