

import java.util.Stack;

public class ReverseService {
	/**
	 * returns the input String reversed, using a Stack of characters
	 * @param s
	 * @return
	 */
	public static String reverse(String s) {
		Stack<Character> stk = new Stack<Character>();
		for(int i=0; i < s.length(); i++)
			stk.push(s.charAt(i));
		String result = "";
		while(!stk.isEmpty()) {
			result = result + stk.pop();
		}
		return result;
	}
}
