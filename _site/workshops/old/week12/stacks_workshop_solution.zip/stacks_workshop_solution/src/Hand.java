import java.util.Stack;

public class Hand {		
	//Q2
	public static Stack<Card> makeHand(int n) {
		Stack<Card> cards = new Stack<Card>();
		for(int i=0; i < n; i++) {
			Card c = new Card();
			c.setRandom();
			System.out.println(c);
			cards.add(c);
		}
		System.out.println();
		return cards;
	}
	
	public static void reverseDisplay(Stack<Card> s) {
		for(int i=0; i < s.size(); i++)
			System.out.println(s.get(i));
	}
	
	
	public static void main(String[] args) {
		Stack<Card> stack;
		stack = makeHand(5);
		reverseDisplay(stack);
	}
}
