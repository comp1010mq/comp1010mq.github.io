

import java.util.Stack;

public class StackDemo {	
	//Q1
	public static void main(String[] args) {	
		Stack<String> stk = new Stack<String>();
		Stack<String> stk2 = new Stack<String>();
		stk.push("unit");
		stk.push("this");
		stk.push("love");
		stk.push("I");
		while(!stk.isEmpty()) {
			System.out.print(stk.peek()+" ");
			stk2.push(stk.pop());
		}
		while(!stk2.isEmpty()) {
			stk.push(stk2.pop());
		}
		System.out.println();
	}
		
	//Q3
	public static int countEven(Stack<Integer> stk) {
		int count = 0;
		for(Integer item: stk)
			if(item % 2 == 0)
				count++;
		return count;
	}
	
	//Q4
	public static Stack<Integer> alternateItems(Stack<Integer> stk) {
		Stack<Integer> temp = new Stack<Integer>();
		for(int i=stk.size() - 1; i>=0; i-=2)
			temp.add(stk.get(i));
		Stack<Integer> result = new Stack<Integer>();
		while(!temp.isEmpty())
			result.push(temp.pop());
		return result;
	}
}
