

import static org.junit.Assert.*;

import java.util.Stack;

import org.junit.Test;

public class StackDemoTest {

	@Test
	public void testAlternateItems() {
		Stack<Integer> s = new Stack<Integer>();
		s.push(2);
		s.push(1);
		s.push(3);
		s.push(8);
		
		Stack<Integer> s2 = StackDemo.alternateItems(s);
		assertEquals(2, s2.size());
		assertEquals(8, s2.pop().intValue());
		assertEquals(1, s2.pop().intValue());
		
		s = new Stack<Integer>();
		
		s.push(2);
		s.push(1);
		s.push(3);
		s.push(8);
		s.push(5);
		
		Stack<Integer> s3 = StackDemo.alternateItems(s);
		assertEquals(3, s3.size());
		assertEquals(5, s3.pop().intValue());
		assertEquals(3, s3.pop().intValue());
		assertEquals(2, s3.pop().intValue());
	}

}
