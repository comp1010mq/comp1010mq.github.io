

import java.util.Stack;

public class ReverseService {
	/**
	 * returns the input String reversed, using a Stack of characters
	 * @param s
	 * @return
	 */
	public static String reverse(String s) {
		return null;
	}
}
