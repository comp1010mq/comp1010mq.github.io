

import java.util.Stack;

public class Hand 
{		
	//Q2
	public static Stack<Card> makeHand(int n) {
		return null; //to be completed
	}
	
	public static void reverseDisplay(Stack<Card> s) {
	}
	
	
	public static void main(String[] args) {
		Stack<Card> stack;
		stack = makeHand(5);
		reverseDisplay(stack);
	}
}
