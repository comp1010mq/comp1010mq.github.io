

import java.util.Stack;

public class StackDemo {	
	//Q1
	public static void main(String[] args) {	
	}
		
	//Q3
	public static int countEven(Stack<Integer> stk) {
		return 0;
	}
	
	//Q4
	public static Stack<Integer> alternateItems(Stack<Integer> stk) {
		return null;
	}
}
