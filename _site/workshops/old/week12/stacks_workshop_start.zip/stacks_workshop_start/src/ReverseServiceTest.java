

import static org.junit.Assert.*;

import org.junit.Test;

public class ReverseServiceTest {

	@Test
	public void testReverse() {
		assertEquals("olleH", ReverseService.reverse("Hello"));
		assertEquals("looc si sihT", ReverseService.reverse("This is cool"));
		assertNull(ReverseService.reverse(null));
		assertEquals(".",ReverseService.reverse("."));
	}
}
