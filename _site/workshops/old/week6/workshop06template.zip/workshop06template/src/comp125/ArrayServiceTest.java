/* *************************** *
 *  DO NOT MODIFY THIS CLASS  *
 * *************************** */

package comp125;

import static org.junit.Assert.*;

import org.junit.Test;

public class ArrayServiceTest {

	@Test
	public void testLinearSearch() {
		//generate an array
		int[] arr = ArrayService.generate(10, 1, 1);

		//search for an item and make sure result is correct
		int location = ArrayService.linearSearch(arr, 1);
		assertEquals(0, location);
		
		arr[0] = 2;
		location = ArrayService.linearSearch(arr, 1);
		assertEquals(1, location);
		
		arr[arr.length - 1] = 6;
		location = ArrayService.linearSearch(arr, 6);
		assertEquals(arr.length - 1 , location);
		
		for(int val = 3; val < 6; val++)
			assertEquals(-1, ArrayService.linearSearch(arr, val));

		arr = null;
		assertEquals(-1, ArrayService.linearSearch(arr, 1));
		
		arr = new int[0];
		assertEquals(-1, ArrayService.linearSearch(arr, 1));
	}

	@Test
	public void testBinarySearch() {
		//generate an array
		int[] arr = ArrayService.generate(10, 1, 1);

		//search for an item and make sure result is correct
		int location = ArrayService.binarySearch(arr, 1);
		assertTrue(location >= 0);

		for(int i=(arr.length - 1)/2; i<arr.length; i++)
			arr[i] = 2;
		location = ArrayService.binarySearch(arr, 1);
		assertTrue(location >= 0);

		arr[arr.length - 1] = 6;
		location = ArrayService.binarySearch(arr, 6);
		assertEquals(arr.length - 1 , location);

		for(int val = 3; val < 6; val++)
			assertEquals(-1, ArrayService.binarySearch(arr, val));
		
		arr = null;
		assertEquals(-1, ArrayService.linearSearch(arr, 1));

		arr = new int[0];
		assertEquals(-1, ArrayService.linearSearch(arr, 1));
	}
}
