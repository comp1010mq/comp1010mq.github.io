package comp125;

public class TripListClient {

	public static void main(String[] args) {
		//an array of 4 Trip objects
		Trip[] trips = generateTripArray(4);
		
		int maxSpeedIndex = getMaxSpeedIndex(trips);
		
		System.out.println("Fastest trip was: "+trips[maxSpeedIndex]);
	}

	public static int getMaxSpeedIndex(Trip[] trips) {
		int result = 0;
		
		for(int i=1; i < trips.length; i++)
			if(trips[i].averageSpeed() > trips[result].averageSpeed())
				result = i;
		return result;
	}

	public static Trip[] generateTripArray(int size) {
		Trip[] result = new Trip[size];

		for(int i=0; i < result.length; i++) {
			double d = 10*i + 1;
			double t = 5*i - 3;
			result[i] = new Trip(d, t);
			System.out.println(result[i]);
		}
		
		return result;
	}
}
