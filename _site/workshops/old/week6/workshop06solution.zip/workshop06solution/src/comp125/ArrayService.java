package comp125;

import java.util.Random;


public class ArrayService {
	public static int[] generate(int size, int low, int high) {
		Random r = new Random();
		int[] a = new int[size];
		for(int i=0; i<a.length; i++) {
			a[i] = low + r.nextInt(high-low+1);
		}
		return a;
	}

	public static int[] generateSortedArray(int size, int low, int high) {
		Random r = new Random();
		int[] a = new int[size];
		for(int i=0; i<a.length; i++) {
			if(i == 0)
				a[i] = low;
			else {
				int inc = r.nextInt(3);
				int value = a[i-1] + inc;
				if(value <= high)
					a[i] = value;
				else
					a[i] = high;
			}
		}
		return a;
	}

	public static void display(int[] b) {
		for(int i=0; i<b.length; i++) {
			if(i > 0 && i%10 == 0)
				System.out.println();
			System.out.print(b[i]+"\t");
		}
	}

	public static boolean isSorted(int[] data) {
		// TODO Auto-generated method stub
		for(int i=1; i<data.length; i++)
			if(data[i] < data[i-1])
				return false;
		return true;
	}

	public static int linearSearch(int[] data, int key) {
		if(data == null || data.length == 0)
			return -1; //not found

		for(int i=0; i<data.length; i++)
			if(data[i] == key) //found!!!
				return i; //return index of the item

		return -1;
	}

	/**
	 * 
	 * @param a, ASSUMED to be in sorted order
	 * @param key
	 * @return
	 */
	public static int binarySearch(int[] data, int key) {
		if(data == null || data.length == 0)
			return -1; //not found

		//set search space
		int first = 0; //first valid index
		int last = data.length - 1; //last valid index

		while(first <= last) { //till some search space is not yet exhausted
			int mid = (first + last)/2; //find median item
			//REMEMBER THE BRACKETS

			if(key == data[mid]) //if median item is your item
				return mid; //return its location

			if(key < data[mid]) //if it exists, it's in the left half
				last = mid - 1; //only consider items on left of median

			if(key  > data[mid]) //if it exists, it's in the right half
				first = mid + 1; //only consider items on right of median
		}

		return -1; //exhausted search space - return -1
	}

	/**
	 * uses binarySearch if array a is sorted in ascending order, otherwise uses linearSearch
	 * @param item
	 * @return
	 */
	public static int search(int[] data, int item) {
		if(isSorted(data))
			return binarySearch(data, item);
		else
			return linearSearch(data, item);
	}
}
