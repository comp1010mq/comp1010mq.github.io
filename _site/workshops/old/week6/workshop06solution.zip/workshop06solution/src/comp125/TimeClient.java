package comp125;

public class TimeClient {

	public static void main(String[] args) {

		Time[] times = generateTimeArray(5);

		int maxTimeIndex = getMaxTimeIndex(times);

		display(times, "original array");

		System.out.println("Max time: "+times[maxTimeIndex]);
		
		//make first item 06:00:00 am (Same as fourth item)
		times[0].setHour(6);
		times[0].setMinute(0);
		times[0].setSecond(0);
		
		display(times, "after changing first item");

		int idx = getLastOccurrence(times, new Time(6,0,0)); //should be 3, not 0
		System.out.println("last occurrence of 06:00:00 am at index "+idx);
		
		Time[] sortedTimes = generateSortedTimeArray(20);

		display(sortedTimes, "original sorted array");

		Time target = new Time(5, 10, 12);

		int loc = binarySearch(sortedTimes, target);

		System.out.println("Time "+target+" found at index "+loc);
		
		Time[] pmTimes = getTimesPast(sortedTimes, new Time(11,22,27));
		
		display(pmTimes, "All times past 11:22:27");
	}

	public static Time[] generateTimeArray(int size) {
		Time[] result = new Time[size];

		for(int i=0; i < result.length; i++) {
			result[i] = new Time(10*i%24, 100*i%60, 140*i%60);
		}
		return result;
	}

	public static int getMaxTimeIndex(Time[] t) {
		int result = 0;

		for(int i=1; i < t.length; i++)
			if(t[i].compareTo(t[result]) > 0)
				result = i;
		return result;
	}

	/**
	 * Precondition size < 24
	 * @param size
	 * @return a time array in sorted order (based on compareTo as defined in Time class)
	 */
	public static Time[] generateSortedTimeArray(int size) {
		Time[] result = new Time[size];

		for(int i=0; i < result.length; i++) {
			result[i] = new Time(i, 2*i, (int)(2.5 * i));
		}
		return result;
	}
	
	public static void display(Time[] times, String header) {
		if(times == null)
			return;
		System.out.println();
		System.out.println("---------------------");
		System.out.println(header+"\n");
		for(int i=0; i < times.length; i++)
			System.out.println(times[i]);
		System.out.println("---------------------");
		System.out.println();
		
	}
	
	/**
	 * 
	 * @param arr
	 * @param target
	 * @return the last index in the array at which the target 
	 * is found. Return -1 if array is null 
	 */
	public static int getLastOccurrence(Time[] arr, Time target) {
		if(arr == null)
			return -1;
		for(int i = arr.length - 1; i >= 0; i--)
			if(target.compareTo(arr[i]) == 0)
				return i;
		return -1;
	}
	
	/**
	 * Precondition: assume array is sorted in ascending order
	 * (based on compareTo method, as defined in Time class)
	 * @param arr
	 * @param target
	 * @return using binary search algorithm, return an index in the array
	 * where target is found. Return -1 if array is empty or target is not found
	 */
	public static int binarySearch(Time[] arr, Time target) {
		if(arr == null)
			return -1;
			
		int first = 0; 
		int last = arr.length - 1;

		// keep going until we're looking at one cell
		while(first <= last) {

			int median = (first + last)/2;
			if (target.compareTo(arr[median]) == 0) {
				return median;
			} 
			if (target.compareTo(arr[median]) < 0) {
				last = median - 1;
			} 
			else {
				first = median + 1;
			}
		}
		return -1;
	}
	
	/**
	 * 
	 * @param arr
	 * @param base
	 * @return  
	 * 
	 */
	public static Time[] getTimesPast(Time[] arr, Time base) {
		if(arr == null)
			return null;
		
		int count = 0;
		for(int i = 0; i < arr.length; i++)
			if(arr[i].compareTo(base) >= 0)
				count++;
		
		Time[] result = new Time[count];
		int k = 0;
		for(int i=0; i < arr.length; i++)
			if(arr[i].compareTo(base) >= 0)
				result[k++] = arr[i];
		
		return result;
	}
}
