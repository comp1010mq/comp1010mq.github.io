package comp125;

public class Trip {
	private double distanceCovered, timeTaken;

	public double getDistanceCovered() {
		return distanceCovered;
	}

	public double getTimeTaken() {
		return timeTaken;
	}

	public void setDistanceCovered(double distanceCovered) {
		this.distanceCovered = Math.abs(distanceCovered);
	}

	public void setTimeTaken(double timeTaken) {
		this.timeTaken = Math.abs(timeTaken);
	}
	
	public Trip(double d, double t) {
		setDistanceCovered(d);
		setTimeTaken(t);
	}
	
	public double averageSpeed() {
		return distanceCovered / timeTaken;
	}
	
	public String toString() {
		return distanceCovered + " kms in "+timeTaken+" hours at an average speed of "+averageSpeed();
	}
	
	public int compareTo(Trip other) {
		if(this.averageSpeed() > other.averageSpeed())
			return 1;
		if(this.averageSpeed() < other.averageSpeed())
			return -1;
		return 0;
	}
}
