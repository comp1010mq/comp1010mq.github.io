

public class RecursionClient {
	public static int foo(int a) {
		int result;
		if(a == 0) {
			result = 0;
		}
		else {
			result = a + foo(a / 2);
		}
		return result;
	}

//	public static int factorial(int n) {
//		return n * factorial(n - 1);
//		if(n == 0)
//			return 0;
//	}

	public static int bar(int a) {
		if(a <= 0)
			return 0;
		if(a % 2 == 0)
			return bar(a/2);
		else
			return 1 + bar(a/2);
	}

	public static int gcd(int a, int b) {
		if(b == 0)
			return a;
		return gcd(b, a%b);
	}

	public static void displayBrackets(int n) {
		if(n == 0)
			return;
		System.out.print("{");
		for(int i=0; i < n - 2; i++) {
			displayBrackets(n - 1);
			System.out.print(", ");
		}
		displayBrackets(n - 1);
		System.out.print("}");	
	}

	public static void main(String[] args) {
	}

}
