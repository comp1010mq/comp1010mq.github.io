

public class SortService {
	public static int nDigits(int n) {
		int count = 0;
		while(n != 0) {
			count++;
			n/=10;
		} //end loop
		return count;
	}	

	/**
	 * Sort the array in ascending order of number of digits.
	 * If data = {21, 8, 923, 16, 457, 9}, 
	 * it should become {8, 9, 21, 16, 923, 457} 
	 * @param data
	 */
	public static void sortNumDigits(int[] data) {
		if(data == null) 
			return;
		for(int i=1; i < data.length; i++) {
			int backup = data[i];
			int k = i - 1;
			while(k >= 0 && nDigits(data[k]) > nDigits(backup)) {
				data[k+1] = data[k];
				k--;
			}
			data[k+1] = backup;
		}
	}

	/**
	 * 
	 * @param n
	 * @return number of non-trivial divisors of n
	 */
	public static int nDivisors(int n) {
		int count = 0;
		for(int i=2; i < n; i++) {
			if(n%i == 0) {
				count++;
			}
		}
		return count;
	}
	
	/**
	 * Sort the array in ascending order of number of divisors.
	 * For example, if data = {24, 1, 65, 31, 25}.
	 * it should become {1, 31, 25, 65, 24}
	 * @param data
	 */
	public static void sortNumberOfDivisors(int[] data) {
		if(data == null) 
			return;
		for(int i=1; i < data.length; i++) {
			int backup = data[i];
			int k = i - 1;
			while(k >= 0 && nDivisors(data[k]) > nDivisors(backup)) {
				data[k+1] = data[k];
				k--;
			}
			data[k+1] = backup;
		}
	}
}
