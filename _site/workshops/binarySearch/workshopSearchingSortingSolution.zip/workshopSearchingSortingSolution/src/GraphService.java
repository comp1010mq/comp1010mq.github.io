

import java.util.Arrays;

public class GraphService {
	public static boolean isValid(int[] degrees) {
		if(degrees == null)
			return false;
		
		if(degrees.length == 0) //empty graph
			return true;
		
		int total = sum(degrees);
		if(total % 2 == 1) //graphs cannot have odd sum of degrees
			return false;
		
		descendingSort(degrees); //put most connected vertex at index 0
		
		int highestDegree = degrees[0];
		
		if(highestDegree == 0) //empty graph
			return true;
		
		//not enough vertices left to connect to most connected vertex
		if(highestDegree >= nonZeroCount(degrees)) 
			return false;

		/*
		 * break all edges from most connected vertex
		 */
		degrees[0] = 0; 
		
		/*
		 * attempt to break edges from original degrees[0] other vertices
		 */
		for(int i=1; i< degrees.length && highestDegree > 0; i++) {
			if(degrees[i] > 0) {
				degrees[i]--;
				highestDegree--;
			}
		}
		
		if(highestDegree > 0) //not enough vertices
			return false;
		
		return isValid(degrees); //repeat process on the reduced graph again
	}

	public static int nonZeroCount(int[] arr) {
		if(arr == null)
			return 0;
		int count = 0;
		for(int item: arr)
			if(item != 0)
				count++;
		return count;
	}

	public static void descendingSort(int[] arr) {
		if(arr == null)
			return;
		
		for(int i=1; i < arr.length; i++) {
			int backup = arr[i];
			int k = i-1;
			while(k>=0 && arr[k] < backup) {
				arr[k+1] = arr[k];
				k--;
			}
			arr[k+1] = backup;
		}
	}

	public static int sum(int[] arr) {
		if(arr == null)
			return 0;
		int result = 0;
		for(int item: arr)
			result+=item;
		return result;
	}
}
