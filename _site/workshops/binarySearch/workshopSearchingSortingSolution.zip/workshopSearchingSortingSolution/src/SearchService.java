public class SearchService {
	/**
	 * 
	 * @param arr sorted in ascending order based on Rectangle:compareTo
	 * @param target
	 * @return an index in arr where target exists
	 */
	public static int binarySearch(Rectangle[] arr, Rectangle target) {
		int first = 0;
		int last = arr.length - 1; 
		while(first <= last) {
			int median = (first+last)/2;
			if(target.compareTo(arr[median]) == 0) 
				return median;
			if(target.compareTo(arr[median]) == 1)
				first = median + 1;
			else
				last = median - 1;
		}
		return -1;
	}
}
