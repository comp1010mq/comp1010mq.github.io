import java.util.Scanner;

public class StringTheory {
	/**
	 * 
	 * @param str
	 * @param ch
	 * @return number of times character ch occurs in str
	 */
	public static int countOccurrences(String str, char ch) {
		return 0; //to be completed
	}

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub		
		System.out.println("'a' occurs "+countOccurrences("Hallelujah", 'a')+" times in Hallelujah"); //2
		System.out.println("'A' occurs "+countOccurrences("Hallelujah", 'A')+" times in Hallelujah"); //0
		System.out.println("'h' occurs "+countOccurrences("Hallelujah", 'h')+" times in Hallelujah"); //1
		System.out.println("'H' occurs "+countOccurrences("Hallelujah", 'H')+" times in Hallelujah"); //1
		System.out.println("'x' occurs "+countOccurrences("Hallelujah", 'x')+" times in Hallelujah"); //0

	}

}
