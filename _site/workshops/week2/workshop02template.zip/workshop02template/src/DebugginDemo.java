
public class DebugginDemo {
	/**
	 * buggy method 1 - for tutor to demonstrate
	 * @param arr
	 * @return sum of all even numbers in the array
	 */
	public static int sumEven(int[] arr) {
		int result = 0;
		for(int i=0; i < arr.length; i++) {
			if(arr[i] % 2 == 0) {
				result = result + i;
			}
		}
		return result;
	}
	
	/**
	 * buggy method 2 - for students to practice
	 * @param arr
	 * @return true if array is in ascending order, false otherwise
	 */
	public static boolean isAscending(int[] arr) {
		for(int i=0; i < arr.length - 1; i++) {
			if(arr[i] >= arr[i+1]) {
				return false;
			}
		}
		return true;
	}
	
	public static void main(String[] args) {
		int[] a = new int[]{0, 1, 2, 3, 4}; 
		//get used to this way of instantiating an array
		int b = sumEven(a); //should be 0 + 2 + 4 = 6: works correctly
		System.out.println(b+" (should be 6)");
		
		a = new int[]{12, 7, -6, 5, 3, 8};
		b = sumEven(a); //should be 12 + -6 + 8 = 14: doesn't work correctly
		System.out.println(b+" (should be 14)");
		
		a = new int[]{5, 3, 5, 6, 2}; 
		boolean c = isAscending(a); //should be false: works correctly
		System.out.println(c+" (should be false)");
		
		a = new int[]{4, 7, 9, 15}; 
		c = isAscending(a); //should be true: works correctly
		System.out.println(c+" (should be true)");
		
		a = new int[]{4, 7, 7, 15}; 
		c = isAscending(a); //should be true: doesn't work correctly
		System.out.println(c+" (should be true)");
	}
}
