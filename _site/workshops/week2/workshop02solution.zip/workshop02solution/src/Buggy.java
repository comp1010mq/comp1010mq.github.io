import java.util.Arrays;

public class Buggy {

	public static void main(String[] args) {
		int[] a = {10, 70, 20, 90};
		int result = 0; //result should be 0, not 1
		for(int i=0; i < a.length; i++) { //start from 0, not 1
			result = result + a[i]; //add a[i], not i
		}
		System.out.println("Sum of all items of "+Arrays.toString(a)+" is "+result);
	}

}
