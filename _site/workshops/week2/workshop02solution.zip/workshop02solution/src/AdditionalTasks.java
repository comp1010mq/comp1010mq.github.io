	public class AdditionalTasks {
	/**
	 * additional task A
	 */
	public static char mostFrequentCharacter(String s) {
		if(s == null || s.length() == 0) //uninstantiated or empty
			return (char)0;

		char maxChar = s.charAt(0);
		int maxOcc = StringTheory.countOccurrences(s, maxChar);

		for(int i=1; i<s.length(); i++) {
			int iOcc = StringTheory.countOccurrences(s, s.charAt(i));
			if(iOcc > maxOcc) {
				maxChar = s.charAt(i);
				maxOcc = iOcc;
			}
		}

		return maxChar;
	}

	/**
	 * additional task B
	 */
	public static String mostFrequentCharacters(String s) {
		if(s == null || s.length() == 0) //uninstantiated or empty
			return "";

		int maxOcc = StringTheory.countOccurrences(s, s.charAt(0));

		for(int i=1; i<s.length(); i++) {
			int iOcc = StringTheory.countOccurrences(s, s.charAt(i));
			if(iOcc > maxOcc) {
				maxOcc = iOcc;
			}
		}

		String result = "";

		for(int i=0; i<s.length(); i++) {
			int iOcc = StringTheory.countOccurrences(s, s.charAt(i));
			if(iOcc == maxOcc && result.indexOf(s.charAt(i)) < 0) {
				result = result + s.charAt(i);
			}
		}

		return result;
	}

	public static int countUnique(double[] a) {
		int count = 0;
		for(int i=0; i < a.length; i++)
			if(countOccurrences(a, a[i]) == 1)
				count++;
		return count;
	}

	private static int countOccurrences(double[] a, double target) {
		int count = 0;
		for(int i=0; i < a.length; i++)
			if(a[i] == target)
				count++;
		return count;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//additional tasks client code
		System.out.println("Most frequent character in \"abysmal\": "+mostFrequentCharacter("abysmal"));
		System.out.println("Most frequent character in \"surreal\": "+mostFrequentCharacter("surreal"));

		System.out.println("Most frequent characters in \"abysmal\": "+mostFrequentCharacters("abysmal"));
		System.out.println("Most frequent characters in \"fantastic\": "+mostFrequentCharacters("fantastic"));
		
		double[] arr = {1.2, 2.4, 1.2, 3.6, 4.8, 3.2, 2.4, 1.2, 4.6};
		System.out.println(countUnique(arr)); //4

		double[] b = {1.2, 2.4, 1.2, 3.6, 4.8, 3.2, 2.4, 1.2};
		System.out.println(countUnique(b)); //3
		
		double[] c = {1.2, 2.4, 1.2, 3.6, 3.2, 2.4, 1.2};
		System.out.println(countUnique(c)); //2
		
		double[] d = {1.2, 2.4, 1.2, 3.2, 2.4, 1.2};
		System.out.println(countUnique(d)); //1
		
		double[] e = {1.2, 2.4, 1.2, 2.4, 1.2};
		System.out.println(countUnique(e)); //0
}

}
