import java.util.Scanner;

public class StringTheory {
	/**
	 * 
	 * @param str
	 * @param ch
	 * @return number of times character ch occurs in str
	 */
	public static int countOccurrences(String str, char ch) {
		int count = 0;

		for(int i=0; i<str.length(); i++) //for each character
			if(str.charAt(i) == ch) //found a match
				count++; //increase number of occurrences by 1

		return count;
	}

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub		
		System.out.println("'a' occurs "+countOccurrences("Hallelujah", 'a')+" times in Hallelujah"); //2
		System.out.println("'A' occurs "+countOccurrences("Hallelujah", 'A')+" times in Hallelujah"); //0
		System.out.println("'h' occurs "+countOccurrences("Hallelujah", 'h')+" times in Hallelujah"); //1
		System.out.println("'H' occurs "+countOccurrences("Hallelujah", 'H')+" times in Hallelujah"); //1
		System.out.println("'x' occurs "+countOccurrences("Hallelujah", 'x')+" times in Hallelujah"); //0

	}

}
