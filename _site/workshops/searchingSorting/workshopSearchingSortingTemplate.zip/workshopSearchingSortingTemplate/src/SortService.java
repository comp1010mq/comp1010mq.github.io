

public class SortService {
	/**
	 * Sort the array in ascending order of number of digits.
	 * If data = {21, 8, 923, 16, 457, 9}, 
	 * it should become {8, 9, 21, 16, 923, 457} 
	 * @param data
	 */
	public static void sortNumDigits(int[] data) {
		boolean FIXME = true; //dummy boolean value to be replaced on line 16
		if(data == null) 
			return;
		for(int i=1; i < data.length; i++) {
			int backup = data[i];
			int k = i - 1;
			while(k >= 0 && FIXME) {
				data[k+1] = data[k];
				k--;
			}
			data[k+1] = backup;
		}
	}

	/**
	 * Sort the array in ascending order of number of divisors.
	 * For example, if data = {24, 1, 65, 31, 25}.
	 * it should become {1, 31, 25, 65, 24}
	 * @param data
	 */
	public static void sortNumberOfDivisors(int[] data) {
		boolean FIXME = true; //dummy boolean value to be replaced on line 16
		if(data == null) 
			return;
		for(int i=1; i < data.length; i++) {
			int backup = data[i];
			int k = i - 1;
			while(k >= 0 && FIXME) {
				data[k+1] = data[k];
				k--;
			}
			data[k+1] = backup;
		}
	}

}
