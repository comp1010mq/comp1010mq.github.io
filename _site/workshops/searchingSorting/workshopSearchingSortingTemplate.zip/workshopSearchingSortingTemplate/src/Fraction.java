import java.util.Scanner;

public class Fraction {
	private int num, den;

	public int getNum() {
		return num;
	}

	public int getDen() {
		return den;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public void setDen(int den) {
		Scanner s = new Scanner(System.in);
		while(den == 0) {
			System.out.print("Denomenator cannot be zero. Re-enter value: ");
			den = s.nextInt();
		}
		s.close();
		this.den = den;

	}

	public Fraction(int n, int d) {
		setNum(n);
		setDen(d);
	}
	
	public Fraction() {
		setNum(0);
		setDen(1);
	}
	
	public String toString() {
		return num+" / "+den+" ("+this.getRealValue()+")";
	}
	
	public double getRealValue() {
		return num * 1.0 / den;
	}
	
	public boolean isPositive() {
		if(getRealValue() > 0)
			return true;
		else
			return false;
	}
	
	public boolean isZero() {
		if(num == 0)
			return true;
		else
			return false;
	}
	
	/**
	 * THIS IS THE REAL DEAL IN TERMS OF SORTING
	 * 
	 * This is the method that sort methods will use to compare two
	 * Fraction objects. You cannot compare two Fraction objects f1 and f2
	 * like f1 > f2, no you can't. you simply can't, I won't let you do it!
	 * Instead of f1 > f2, we use f1.compareTo(f2) == 1
	 * Similarly for f1 < f2, it's f1.compareTo(f2) == -1
	 * and for f1 == f2, it's f1.compareTo(f2) == 0, OR, f1.equals(f2) == true
	 * @param other
	 * @return
	 * 1 if this object has a higher floating point value than the passed object
	 * -1 if this object has a lower floating point value than the passed object
	 * 1 if this object and the passed object have the same floating point value
	 */
	public int compareTo(Fraction other) {
		return 0; //to be completed
	}
	
	/**
	 * two fractions are equal if they are exactly the same in the reduced form
	 * Eg., 2/5 and 40/100 are the same
	 * @param other
	 * @return
	 */
	public boolean equals(Fraction other) {
		Fraction r1 = reduce();
		Fraction r2 = other.reduce();
		if(r1.num == r2.num && r1.den == r2.den)
			return true;
		else
			return false;
	}
	
	/**
	 * reduce fraction to simplest possible form
	 * Eg., 40/100 is reduced to 2/5
	 * @return
	 */
	public Fraction reduce() {
		int min = Math.min(num, den);
		for(int i=min; i>1; i--) {
			if(num%i==0 && den%i==0) {
				Fraction result = new Fraction(num/i, den/i);
				return result;
			}
		}
		Fraction result = new Fraction(num, den); //no common divisors
		return  result;
	}
}
