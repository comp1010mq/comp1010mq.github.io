package sorting;

public class Main {

	public static void main(String[] args) {
		int[] values = {3,2,4,5,3,6,7,9,8,5,9,3,5,1};
		//Sorter s = new Bubble();
		Sorter s = new BuiltIn();
		int[] sorted = s.sort(values);
		for (int i = 0; i< sorted.length; i++){
			System.out.println(sorted[i]);
		}
	}

}
