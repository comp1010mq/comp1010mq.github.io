package sorting;

public class BuiltIn implements Sorter {

	@Override
	public int[] sort(int[] input) {
	  java.util.Arrays.sort(input);
	  return input;
	}
	
}
