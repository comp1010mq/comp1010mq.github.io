package sorting;

public class Bubble implements Sorter {

	@Override
	public int[] sort(int[] input) {
		int stash;
		for(int i = 0; i < input.length -1; i++){
			for(int j = 1; j< input.length-i; j++){
				if(input[j-1] > input[j]){
					stash = input[j-1];
					input[j-1]=input[j];
					input[j] = stash;
				}
			}
		}
		return input;
	}

}
