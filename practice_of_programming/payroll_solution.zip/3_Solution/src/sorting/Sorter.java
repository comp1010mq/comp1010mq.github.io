package sorting;

public interface Sorter {
	public abstract int[] sort(int[] input);
}
