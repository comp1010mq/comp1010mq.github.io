package payroll;

import java.util.Vector;

public class PayRoll {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Vector<Employee> Elist = new Vector<Employee>(4);
		FullTime Fred = new FullTime("Fred", "Smith", 1000);
		FullTime Samantha = new FullTime("Samantah", "Simons", 1500);
		PartTime Dame = new PartTime("Dame Edna", "Everage", 1000, 40);
		PartTime Angelina = new PartTime("Angelina", "Jolie", 1000, 25);
		Elist.add(Fred);Elist.add(Samantha); Elist.add(Dame); Elist.add(Angelina);
		System.out.println(Elist);
		System.out.println(Angelina.earnings());
		try {
			Fred.setSalary(-1);
		} catch (PayrollException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.err.println(e.errorMessage);
			e.printStackTrace();
			
		}
		

	}

}
