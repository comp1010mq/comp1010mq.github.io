package payroll;

public class FullTime extends Employee{ // Why are there errors?
    
    private double baseSalary;
    
    // Constructor
    // To implement
    public FullTime (String first, String last, double s){
    	super(first, last);
    	baseSalary = s;
    }

    public void  setSalary(double s) throws PayrollException {
         if (s<0) throw new PayrollException("Negative input is not allowed");
         baseSalary= s;
    }
    
   // You need to implement earnings
    
    public String toString() {
        return "Full time: " + getFirst() + " " + getFamily() + ", Salary: " + baseSalary;
    }

	@Override
	double earnings() {
		return baseSalary;
	}
    
}