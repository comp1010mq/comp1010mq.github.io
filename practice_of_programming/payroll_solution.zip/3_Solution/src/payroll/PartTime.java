package payroll;

public class PartTime extends Employee{ // Why are there errors?
    
    private double hourlyRate;
    private int hours;
    private double salary;
    
    // Constructor
    // To implement
    public PartTime (String first, String last, double r, int h){
    	super(first, last);
    	hourlyRate = r;
    	hours = h;
    }
    
   // You need to implement earnings
    
    public String toString() {
        return "Part time: " + getFirst() + " " + getFamily() + ", Hours: " + hours + ", Rate:" + hourlyRate;
    }

	@Override
	double earnings() {
		// TODO Auto-generated method stub hourlyRate*hours + hourlyRate*Math.max(hours - 35,0)*1.5
		salary = hourlyRate*Math.min(hours, 35) + hourlyRate*Math.max(hours - 35,0)*1.5;
		return salary;
	}
    
}