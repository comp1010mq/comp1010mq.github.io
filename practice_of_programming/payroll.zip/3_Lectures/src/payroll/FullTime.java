package payroll;

public class FullTime extends Employee{ // Why are there errors?
	
	private double baseSalary;
	
	// Constructor
	// To implement

	public void  setSalary(double s) {
		 baseSalary= s;
	}
	
   // You need to implement earnings
	
	public String toString() {
		// To implement
	}
	
}
