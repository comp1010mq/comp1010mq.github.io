package payroll;

public final class PartTime extends Employee {
	
	private double hourlyRate;
	private double hours;
	
	// Constructor
	// You need to implement a constructor

	public void  setRate(double s) { 
		 hourlyRate= s;
	}
	
	public void  setHours(double h)  {
		 hours= h;
	}
	
	// You need to implement earnings
	
	public String toString() {
		// To implement
	}

}
