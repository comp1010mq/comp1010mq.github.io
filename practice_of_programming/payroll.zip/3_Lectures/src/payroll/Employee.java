package payroll;

public abstract class Employee {

	private String firstName;
	private String familyName;
	
	// constructor
	
	public Employee (String first, String last) {
		firstName= first;
		familyName= last;
	}
	
	// getters	
	public String getFirst() {
		return firstName;
	}
	
	public String getFamily() {
		return familyName;
	}
	
	public String toString() {
		return firstName + ' ' + familyName; // ToDo
	}
	
	// This is an abstract method which is implemented
	// differently depending on the type of employee.
	abstract double earnings();
}

@SuppressWarnings("serial")	
class PayrollException extends Exception { 
	String errorMessage;
	PayrollException(String _errorCode) { errorMessage= _errorCode; }
}
